package com.company;
import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class BlackJack {
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        int gamenumber = 1;
        int playerScore = 0;
        int dealerScore = 0;
        int tiedGames = 0;
        int option;
        Random ran = new Random();
        System.out.println("START GAME #" + gamenumber + "!");
        int playermumber = ran.nextInt(13) + 1;
        int playnum;
        if (playermumber > 10 && playermumber < 14) {
            playnum= 10;
        } else {
            playnum= playermumber;
        }
        if (playermumber == 1)
            System.out.println("Ace!");
        else if (playermumber == 11)
            System.out.println("Jack!");
        else if (playermumber == 12)
            System.out.println("Queen!");
        else if (playermumber == 13)
            System.out.println("King");
        else {
            System.out.println("Your card is a: " + playermumber);
        }
        System.out.println("Your hand is a: " + playnum);

        System.out.println();
        System.out.println("1.Get another card.");
        System.out.println("2.Hold hand");
        System.out.println("3.Print Statistics");
        System.out.println("4.Exit");
        System.out.print("Choose an option:");
        option = scnr.nextInt();

        int cardTotal =0;
        int nextCard;


        if (option == 1) {
            while(cardTotal < 22) {   //start while loop
                Random rananother = new Random();
                int Autormumber = rananother.nextInt(13) + 1;
                if (Autormumber > 10 && Autormumber < 14) {
                    cardTotal += 10;
                } else {
                    cardTotal += Autormumber;
                }
                if (Autormumber == 1) {
                    System.out.println("Your Card is a: Ace!");
                    System.out.println("Your total is " + (cardTotal + playnum));
                } else if (Autormumber == 11) {
                    System.out.println("Your Card is a: Jack!");
                    System.out.println("Your total is " + (cardTotal + playnum));
                } else if (Autormumber == 12) {
                    System.out.println("Your Card is a: Queen!");
                    System.out.println("Your total is " + (cardTotal + playnum));
                } else if (Autormumber == 13) {
                    System.out.println("Your Card is a: King");
                    System.out.println("Your total is " + (cardTotal + playnum));
                } else {
                    System.out.println("Your card is a: " + Autormumber);
                    System.out.println("Your total is " + (cardTotal + playnum));
                }

                if ((cardTotal + playnum) > 21) {
                    System.out.println("You exceeded 21! You lose:(");
                    gamenumber = gamenumber + 1;
                    break;
                } else if ((cardTotal + playnum) == 21) {
                    System.out.println("BLACKJACK! You won!");
                    gamenumber = gamenumber + 1;
                    playerScore = playerScore +1;
                    break;
                }
                //   else
                //put menu here
                Optionmenu();
            }   //end of while <21


        }//end of while

        if (option == 2){
            if (dealerScore > playerScore && dealerScore <= 21){
                System.out.println("Dealer wins!");
                System.out.println();
                dealerScore = dealerScore +1;
                gamenumber = gamenumber+1;
            }

            else if(dealerScore < playerScore && playerScore <= 21){
                System.out.println("Player wins!");
                System.out.println();
                playerScore = playerScore + 1;
                gamenumber = gamenumber+1;

            }

            else if(dealerScore == playerScore){
                System.out.println("Tie! No one wins");
                System.out.println();
                gamenumber = gamenumber+1;

            }
            else {
                Optionmenu();
            }

        }

        if (option == 3){
            System.out.println("Number of Player wins: " + playerScore);
            System.out.println("Number of Dealer wins: " + dealerScore);
            System.out.println("Number of tie games: " + tiedGames);
            System.out.println("Total # of games played: " + gamenumber);
            System.out.println("Percentage of Player wins: " + ((double) playerScore / (double) gamenumber )*100 + "%");
        }

        if (option == 4)
            System.exit(0);
        if (option != 4 && option != 3 && option != 2 && option != 1) {
            System.out.println("Invalid input");
            Optionmenu();
        }

        //  gameon=false;//  choose 4 to exit, set to false

    }
    //Option Menu

    private static void Optionmenu()
    {
        int option;
        Scanner scnr = new Scanner(System.in);
        System.out.println("1. Get another card");
        System.out.println("2. Hold hand");
        System.out.println("3. Print Statistics");
        System.out.println("4. Exit");
        System.out.print("Choose an option: ");

        option = scnr.nextInt();
    }


}